﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paintionary.Models
{
    public class clsJugadorConPosicionFinal : clsJugador
    {
        public int PosicionFinal { get; set; }
    }
}
